import 'package:flutter/material.dart';
import 'home_screen.dart';
import 'profile_screen.dart';
import 'dart:async';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'postfounditem_screen.dart';
import 'postlostitem_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: const MyPostsScreen(),
    );
  }
}

class MyPostsScreen extends StatefulWidget {
  const MyPostsScreen({super.key});

  @override
  State<MyPostsScreen> createState() => _MyPostsScreenState();
}

class _MyPostsScreenState extends State<MyPostsScreen> {
  final List<Map<String, dynamic>> posts = [
    {
      'imageUrl': 'https://images.unsplash.com/photo-1632822300275-9867abf24bbe?w=500&h=500',
      'title': 'Beautiful Sunset',
      'category': 'Nature',
      'date': '2023-10-15',
      'time': '18:30',
      'location': '33.6844,73.0479',
      'description': 'Captured this amazing sunset during my evening walk. The colors were breathtaking!',
      'phoneNumber': '+923001234567',
    },
    {
      'imageUrl': 'https://images.unsplash.com/photo-1603959823148-f60a3f4d4b09?w=500&h=500',
      'title': 'Mountain Hike',
      'category': 'Adventure',
      'date': '2023-10-12',
      'time': '09:00',
      'location': '34.0150,73.0289',
      'description': 'Completed this challenging hike with friends. The view from the top was worth it!',
      'phoneNumber': '+923001234567',
    },
    {
      'imageUrl': 'https://images.unsplash.com/flagged/photo-1554757388-5982229b9ce7?w=500&h=500',
      'title': 'Coffee Time',
      'category': 'Food',
      'date': '2023-10-10',
      'time': '15:00',
      'location': '31.5204,74.3587',
      'description': 'Enjoying my favorite coffee at the new cafe downtown. Perfect blend!',
      'phoneNumber': '+923001234567',
    },
  ];

  int _currentIndex = 1;

  void _navigateToDetailScreen(BuildContext context, Map<String, dynamic> post) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => DetailScreen(
          title: post['title'],
          category: post['category'],
          date: post['date'],
          time: post['time'],
          location: post['location'],
          description: post['description'],
          imagePath: post['imageUrl'],
          buttonColor: Colors.blue,
          phoneNumber: post['phoneNumber'],
          buttonText: "Contact Owner",
        ),
      ),
    );
  }

  void _showComingSoonMessage(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Chat feature will be available in future updates!'),
        backgroundColor: Colors.red, // Changed color to red
        duration: Duration(seconds: 2),
      ),
    );
  }

  void _showAddPostModal(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (BuildContext context) {
        return Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
          ),
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                  padding: EdgeInsets.all(16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Create Post",
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                      IconButton(
                        icon: Icon(Icons.close),
                        onPressed: () => Navigator.pop(context),
                      ),
                    ],
                  )),
              Divider(height: 1),
              Padding(
                padding: EdgeInsets.all(16),
                child: Column(
                  children: [
                    SizedBox(height: 10),
                    Text(
                      "What do you want to post?",
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: 20),
                    ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => const PostFoundItemScreen()),
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                        minimumSize: Size(double.infinity, 50),
                      ),
                      child: Text("Post Found Item"),
                    ),
                    SizedBox(height: 16),
                    ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => const PostLostItemScreen()),
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red,
                        minimumSize: Size(double.infinity, 50),
                      ),
                      child: Text("Post Lost Item"),
                    ),
                    SizedBox(height: 10),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: const Text('My Posts'),
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 1,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(height: 20),
            const CircleAvatar(
              radius: 50,
              backgroundImage: NetworkImage(
                  'https://images.unsplash.com/photo-1524290266577-e90173d9072a?w=500&h=500'),
            ),
            const SizedBox(height: 10),
            const Text(
              'Maria Riaz',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              'Total Posts: ${posts.length}',
              style: const TextStyle(color: Colors.grey),
            ),
            const SizedBox(height: 20),
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                crossAxisSpacing: 16,
                mainAxisSpacing: 16,
                childAspectRatio: 1,
              ),
              itemCount: posts.length,
              itemBuilder: (context, index) {
                return GestureDetector(
                  onTap: () => _navigateToDetailScreen(context, posts[index]),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.1),
                          blurRadius: 4,
                          offset: const Offset(0, 2),
                        )
                      ],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.network(
                        posts[index]['imageUrl'],
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) {
                          return const Icon(Icons.error);
                        },
                      ),
                    ),
                  ),
                );
              },
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
          switch (index) {
            case 0:
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => HomeScreen()),
              );
              break;
            case 1:
              break;
            case 2:
              _showAddPostModal(context); // Show add post modal
              break;
            case 3:
              _showComingSoonMessage(context); // Show red coming soon message
              break;
            case 4:
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => ProfileScreen()),
              );
              break;
          }
        },
        selectedItemColor: Colors.blueAccent,
        unselectedItemColor: Colors.black54,
        showUnselectedLabels: true,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.article), label: 'My Posts'),
          BottomNavigationBarItem(icon: Icon(Icons.add_circle_outline), label: 'Add Post'),
          BottomNavigationBarItem(icon: Icon(Icons.chat_bubble_outline), label: 'Chat'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

class DetailScreen extends StatelessWidget {
  final String title;
  final String category;
  final String date;
  final String time;
  final String location;
  final String description;
  final String imagePath;
  final Color buttonColor;
  final String phoneNumber;
  final String buttonText;

  DetailScreen({
    required this.title,
    required this.category,
    required this.date,
    this.time = "Not Specified",
    required this.location,
    required this.description,
    required this.imagePath,
    required this.buttonColor,
    required this.phoneNumber,
    required this.buttonText,
  });

  final Completer<GoogleMapController> _controller = Completer();

  @override
  Widget build(BuildContext context) {
    LatLng latLng = _parseLocation(location);

    return Scaffold(
      appBar: AppBar(title: Text("Post Details")),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Image.network(
                imagePath,
                width: 200,
                height: 200,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) =>
                    Icon(Icons.image_not_supported, size: 100),
              ),
            ),
            const SizedBox(height: 20),
            Text("Title: $title", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            Text("Category: $category", style: TextStyle(fontSize: 18)),
            Text("Date: $date", style: TextStyle(fontSize: 16, color: Colors.grey)),
            Text("Time: $time", style: TextStyle(fontSize: 16, color: Colors.grey)),
            const SizedBox(height: 10),
            Text("Location:", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Container(
              height: 200,
              child: GoogleMap(
                initialCameraPosition: CameraPosition(target: latLng, zoom: 14.0),
                markers: {Marker(markerId: MarkerId("itemLocation"), position: latLng)},
                onMapCreated: (GoogleMapController controller) {
                  _controller.complete(controller);
                },
              ),
            ),
            const SizedBox(height: 10),
            Text("Description:", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Text(description, style: TextStyle(fontSize: 16)),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => _makePhoneCall(phoneNumber),
              style: ElevatedButton.styleFrom(backgroundColor: buttonColor),
              child: Text(buttonText, style: TextStyle(color: Colors.white)),
            ),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                FloatingActionButton(
                  onPressed: () => _makePhoneCall(phoneNumber),
                  backgroundColor: Colors.purple,
                  child: Icon(Icons.call, color: Colors.white),
                ),
                FloatingActionButton(
                  onPressed: () => _openWhatsApp(phoneNumber),
                  backgroundColor: Colors.green,
                  child: Icon(Icons.chat, color: Colors.white),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  LatLng _parseLocation(String location) {
    try {
      List<String> latLng = location.split(",");
      return LatLng(double.parse(latLng[0]), double.parse(latLng[1]));
    } catch (e) {
      return LatLng(33.6844, 73.0479);
    }
  }

  void _makePhoneCall(String phoneNumber) async {
    final Uri uri = Uri(scheme: "tel", path: phoneNumber);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    } else {
      print("Could not launch phone dialer");
    }
  }

  void _openWhatsApp(String phoneNumber) async {
    final Uri uri = Uri.parse("https://wa.me/$phoneNumber");
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    } else {
      print("Could not launch WhatsApp");
    }
  }
}