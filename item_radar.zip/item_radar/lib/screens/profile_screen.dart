import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:item_radar/screens/createpost_screen.dart';
import 'package:item_radar/screens/reportproblem_screen.dart';
import 'package:item_radar/screens/welcome_screen.dart';
import 'package:item_radar/screens/home_screen.dart' as home;// Keep this if needed
import 'package:item_radar/screens/mypost_screen.dart';
import 'editprofile_screen.dart';
import 'package:item_radar/screens/shareapp_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: const ProfileScreen(),
    );
  }
}

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  int _selectedIndex = 4;
  bool _notificationsEnabled = true;
  bool _darkModeEnabled = false;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });

    switch (index) {
      case 0:
        Navigator.push(
          context,
            MaterialPageRoute(builder: (context) => home.HomeScreen())
        );
        break;
      case 1:
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => MyPostsScreen()),
        );
        break;
      case 2:
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => AddPostScreen()),
        );
        break;
      case 3:
      // Chat screen navigation would go here
        break;
      case 4:
      // This is the current screen, no navigation needed
        break;
    }
  }

  void _showLogoutDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Do you want to logout from Item Radar?'),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('No'),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => const WelcomeScreen()),
                );
              },
              child: const Text('Yes'),
            ),
          ],
        );
      },
    );
  }

  void _showDeleteAccountDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Are you sure you want to delete your account?'),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('No'),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => const WelcomeScreen()),
                );
              },
              child: const Text('Yes'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _darkModeEnabled ? Colors.black : Colors.grey[200],
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              const SizedBox(height: 20),
              Center(
                child: Column(
                  children: [
                    const CircleAvatar(
                      radius: 50,
                      backgroundImage: NetworkImage(
                        'https://images.unsplash.com/photo-1525069011944-e7adfe78b280?w=800&h=800',
                      ),
                    ),
                    const SizedBox(height: 10),
                    const Text(
                      'Hafsakanwal',
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    const Text(
                      '@hafsakanwal',
                      style: TextStyle(color: Colors.grey),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              Container(
                margin: const EdgeInsets.symmetric(horizontal: 20),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: _darkModeEnabled ? Colors.grey[850] : Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(color: Colors.black12, blurRadius: 6, spreadRadius: 1),
                  ],
                ),
                child: Column(
                  children: [
                    _buildProfileOption(Icons.edit, 'Edit Profile', () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => const EditProfileScreen()),
                      );
                    }),
                    _buildSwitchOption('Notifications', _notificationsEnabled, (newValue) {
                      setState(() => _notificationsEnabled = newValue);
                    }),
                    _buildSwitchOption('Enable Dark Mode', _darkModeEnabled, (newValue) {
                      setState(() => _darkModeEnabled = newValue);
                    }),
                    _buildProfileOption(Icons.delete, 'Delete Account', _showDeleteAccountDialog, Colors.red),
                    _buildProfileOption(Icons.report, 'Report a Problem', () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => const ReportProblemScreen()),
                      );
                    }),
                    _buildProfileOption(Icons.share, 'Share App', () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => ShareAppScreen()),
                      );
                    }),
                    _buildProfileOption(Icons.logout, 'Logout', _showLogoutDialog, Colors.red),
                  ],
                ),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        selectedItemColor: Colors.blueAccent,
        unselectedItemColor: Colors.black54,
        showUnselectedLabels: true,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.article), label: 'My Posts'),
          BottomNavigationBarItem(icon: Icon(Icons.add_circle_outline), label: 'Add Post'),
          BottomNavigationBarItem(icon: Icon(Icons.chat_bubble_outline), label: 'Chat'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }

  Widget _buildProfileOption(IconData icon, String text, VoidCallback? onTap, [Color? color]) {
    return ListTile(
      leading: Icon(icon, color: color ?? Colors.black54),
      title: Text(text, style: TextStyle(color: color ?? Colors.black)),
      trailing: const Icon(Icons.arrow_forward_ios, size: 16, color: Colors.black54),
      onTap: onTap,
    );
  }

  Widget _buildSwitchOption(String text, bool value, Function(bool) onChanged) {
    return SwitchListTile(
      title: Text(text),
      value: value,
      onChanged: onChanged,
    );
  }
}