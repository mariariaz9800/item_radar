import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'profile_screen.dart'; // Import ProfileScreen
import 'sort_screen.dart'; // Import SortScreen
import 'filter_screen.dart';
import 'package:item_radar/screens/mypost_screen.dart';
import 'item_detail_screen.dart'; // Added import for ItemDetailScreen
import 'postfounditem_screen.dart';
import 'postlostitem_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;
  String selectedCategory = 'All';

  List<Map<String, dynamic>> allItems = [
    {
      'title': 'Laptop',
      'category': 'Electronics',
      'location': '33.6007, 73.0679', // Islamabad coordinates
      'time': '14:30',
      'date': '12 Jan 2024',
      'description': 'Black laptop found near the library',
      'images': [
        'https://images.unsplash.com/photo-1662252900942-2d7e1feb6494?w=500&h=500',
        null,
        null
      ],
      'buttonText': 'loss',
      'buttonColor': Colors.orange
    },
    {
      'title': 'Glasses',
      'category': 'Accessories',
      'location': '33.7681, 72.3612', // Attock coordinates
      'time': '10:15',
      'date': '2 Feb 2024',
      'description': 'Black framed glasses found in the park',
      'images': [
        'https://th.bing.com/th/id/OIP.V-fXGF5XyIn_Y7yduNomPwHaE7?rs=1&pid=ImgDetMain',
        null,
        null
      ],
      'buttonText': 'Found',
      'buttonColor': Colors.green
    },
    {
      'title': 'Ring',
      'category': 'Jewelry',
      'location': '33.6007, 73.0679', // Islamabad coordinates
      'time': '09:45',
      'date': '4 Feb 2024',
      'description': 'Gold ring with diamond found near the fountain',
      'images': [
        'https://images.unsplash.com/photo-1693222080378-5675baf4e1e6?w=500&h=500',
        null,
        null
      ],
      'buttonText': 'Found',
      'buttonColor': Colors.green
    },
    {
      'title': 'pencil',
      'category': 'Stationary',
      'location': '33.6007, 73.0679', // Islamabad coordinates
      'time': '16:20',
      'date': '10 Feb 2024',
      'description': 'Mechanical pencil lost during the lecture',
      'images': [
        'https://images.unsplash.com/photo-1661732017082-a82ecf38af87?w=500&h=500',
        null,
        null
      ],
      'buttonText': 'loss',
      'buttonColor': Colors.orange
    },
    {
      'title': 'Markers',
      'category': 'Stationary',
      'location': '33.5651, 73.0169', // Rawalpindi coordinates
      'time': '11:30',
      'date': '15 Feb 2024',
      'description': 'Set of colored markers lost in the art classroom',
      'images': [
        'https://images.unsplash.com/photo-1632822300275-9867abf24bbe?w=500&h=500',
        null,
        null
      ],
      'buttonText': 'Lost',
      'buttonColor': Colors.orange
    },
    {
      'title': 'Shoes',
      'category': 'Accessories',
      'location': '33.7681, 72.3612', // Attock coordinates
      'time': '17:15',
      'date': '18 Feb 2024',
      'description': 'Running shoes lost near the gym',
      'images': [
        'https://images.unsplash.com/photo-1658574917557-60fbafa05953?w=500&h=500',
        null,
        null
      ],
      'buttonText': 'Lost',
      'buttonColor': Colors.orange
    },
    {
      'title': 'Calculator',
      'category': 'Electronics',
      'location': '33.5651, 73.0169', // Rawalpindi coordinates
      'time': '13:45',
      'date': '20 Feb 2024',
      'description': 'Scientific calculator found in the math department',
      'images': [
        'https://www.autodesk.com/products/fusion-360/blog/wp-content/uploads/2023/03/calculator-gdc0b8a6a8_1920.jpg',
        null,
        null
      ],
      'buttonText': 'Found',
      'buttonColor': Colors.green
    },
    {
      'title': 'Pen',
      'category': 'Stationary',
      'location': '33.5651, 73.0169', // Rawalpindi coordinates
      'time': '15:00',
      'date': '22 Feb 2024',
      'description': 'Blue ballpoint pen lost during meeting',
      'images': [
        'https://th.bing.com/th/id/R.383ded42d84f216ac8e73f9f6d90b1ba?rik=1VgVIbl1WlFYOg&pid=ImgRaw&r=0',
        null,
        null
      ],
      'buttonText': 'Lost',
      'buttonColor': Colors.orange
    },
    {
      'title': 'Camera',
      'category': 'Electronics',
      'location': '33.6007, 73.0679', // Islamabad coordinates
      'time': '14:15',
      'date': '25 Feb 2024',
      'description': 'Digital camera found near the exhibition hall',
      'images': [
        'https://images.unsplash.com/photo-1505260325041-5e73f5831859?w=500&h=500',
        null,
        null
      ],
      'buttonText': 'Found',
      'buttonColor': Colors.green
    },
    {
      'title': 'Pink bottle',
      'category': 'Accessories',
      'location': '33.7681, 72.3612', // Attock coordinates
      'time': '16:30',
      'date': '27 Feb 2024',
      'description': 'Pink water bottle lost near the cafeteria',
      'images': [
        'https://th.bing.com/th/id/R.3fe3c172a6064e9d39b053aa9a5ebff9?rik=hsilNLBroV0eLA&riu=http%3a%2f%2fmusclerepublic.com%2fcdn%2fshop%2ffiles%2fMP_PINK.jpg%3fv%3d1686271272&ehk=K1310FFKYQJujtUpbLSWyVezudos%2f3owPfucDujFOzI%3d&risl=&pid=ImgRaw&r=0',
        null,
        null
      ],
      'buttonText': 'Lost',
      'buttonColor': Colors.orange
    },
  ];

  List<Map<String, dynamic>> getFilteredItems() {
    if (selectedCategory == 'All') {
      return allItems;
    } else {
      return allItems
          .where((item) => item['buttonText'] == selectedCategory)
          .toList();
    }
  }

  void _onItemTapped(int index) {
    if (index == 1) {
      Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) =>
            const MyPostsScreen()), // Navigate to MyPostScreen
      );
    }
    else if (index == 2) {
      _showAddPostModal(context);
    } else if (index == 3) {
      // Show red message when chat icon is clicked
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text(
            'Chat feature will be available in future updates!',
            style: TextStyle(color: Colors.white),
          ),
          backgroundColor: Colors.red,
          duration: const Duration(seconds: 2),
        ),
      );
    } else if (index == 4) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => const ProfileScreen()),
      );
    } else {
      setState(() {
        _selectedIndex = index;
      });
    }
  }
  void _showAddPostModal(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (BuildContext context) {
        return Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
          ),
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                  padding: EdgeInsets.all(16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Create Post",
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                      IconButton(
                        icon: Icon(Icons.close),
                        onPressed: () => Navigator.pop(context),
                      ),
                    ],
                  )),
              Divider(height: 1),
              Padding(
                padding: EdgeInsets.all(16),
                child: Column(
                  children: [
                    SizedBox(height: 10),
                    Text(
                      "What do you want to post?",
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: 20),
                    ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => const PostFoundItemScreen()),
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                        minimumSize: Size(double.infinity, 50),
                      ),
                      child: Text("Post Found Item"),
                    ),
                    SizedBox(height: 16),
                    ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => const PostLostItemScreen()),
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red,
                        minimumSize: Size(double.infinity, 50),
                      ),
                      child: Text("Post Lost Item"),
                    ),
                    SizedBox(height: 10),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
  @override
  Widget build(BuildContext context) {
    List<Map<String, dynamic>> filteredItems = getFilteredItems();

    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false, // This removes the back button
        backgroundColor: Colors.white,
        elevation: 0,
        title: Row(
          children: [
            Expanded(
              child: TextField(
                decoration: InputDecoration(
                  hintText: 'Search items...',
                  prefixIcon: const Icon(Icons.search),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30),
                    borderSide: BorderSide.none,
                  ),
                  fillColor: Colors.grey[200],
                  filled: true,
                ),
              ),
            ),
            const SizedBox(width: 10),
            IconButton(
              icon: const Icon(Icons.filter_list, color: Colors.black),
              onPressed: () {
                // Navigate to the FilterScreen when the filter icon is clicked
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          FilterScreen()), // Open FilterScreen
                );
              },
            ),
            IconButton(
              icon: const Icon(Icons.sort, color: Colors.black),
              onPressed: () {
                // Navigate to SortScreen when the sort icon is clicked
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => SortScreen()),
                );
              },
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          Container(
            color: Colors.grey[300],
            padding: const EdgeInsets.symmetric(vertical: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildCategoryButton('All'),
                _buildCategoryButton('Found'),
                _buildCategoryButton('Lost'),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              children: filteredItems.map((item) {
                return _buildItemCard(
                  item['title'],
                  item['category'],
                  item['location'],
                  item['time'],
                  item['date'],
                  item['description'],
                  item['images'],
                  item['buttonText'],
                  item['buttonColor'],
                );
              }).toList(),
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        selectedItemColor: Colors.blueAccent,
        unselectedItemColor: Colors.black54,
        showUnselectedLabels: true,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.article), label: 'My Posts'),
          BottomNavigationBarItem(
              icon: Icon(Icons.add_circle_outline), label: 'Add Post'),
          BottomNavigationBarItem(
              icon: Icon(Icons.chat_bubble_outline), label: 'Chat'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }

  Widget _buildCategoryButton(String category) {
    return GestureDetector(
      onTap: () {
        setState(() {
          selectedCategory = category;
        });
      },
      child: Text(
        category,
        style: TextStyle(
          color: selectedCategory == category ? Colors.blue : Colors.black,
          fontWeight: selectedCategory == category
              ? FontWeight.bold
              : FontWeight.normal,
        ),
      ),
    );
  }

  Widget _buildItemCard(
      String title,
      String category,
      String location,
      String time,
      String date,
      String description,
      List<String?> images,
      String buttonText,
      Color buttonColor,
      ) {
    return Card(
      margin: const EdgeInsets.all(10),
      child: ListTile(
        onTap: () {
          // Convert location String to LatLng object
          List<String> parts = location.split(',');
          double latitude = double.parse(parts[0].trim());
          double longitude = double.parse(parts[1].trim());
          LatLng locationLatLng = LatLng(latitude, longitude);

          // Navigate to the detail screen
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => ItemDetailScreen(
                title: title,
                category: category,
                location: locationLatLng,
                time: time,
                date: date,
                description: description,
                images: images,
                status: buttonText,
                buttonColor: buttonColor,
              ),
            ),
          );
        },
        leading: ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: Image.network(
            images[0] ?? 'https://via.placeholder.com/50',
            width: 50,
            height: 50,
            fit: BoxFit.cover,
            errorBuilder: (context, error, stackTrace) =>
            const Icon(Icons.image_not_supported, size: 50),
          ),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(category, style: const TextStyle(color: Colors.grey)),
            Text(date, style: const TextStyle(color: Colors.grey)),
          ],
        ),
        trailing: ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: buttonColor,
          ),
          onPressed: () {},
          child: Text(buttonText),
        ),
      ),
    );
  }
}