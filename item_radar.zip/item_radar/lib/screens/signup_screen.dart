import 'package:flutter/material.dart';
import 'home_screen.dart'; // Import HomeScreen

class SignUpScreen extends StatefulWidget {
  @override
  _SignUpScreenState createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  int selectedCategory = 0; // 0 = Student, 1 = Teacher, 2 = Other
  final _formKey = GlobalKey<FormState>(); // Form validation key
  bool _obscurePassword = true; // Toggle for password visibility

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        title: const Text("Sign Up"),
        backgroundColor: Color(0xFFFFA500), // Set app bar color to orange (#FFA500)
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24.0),
          child: SingleChildScrollView(
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const SizedBox(height: 20),
                  const Text(
                    "Create Account",
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    "Join Item Radar as a ${selectedCategory == 0 ? 'Student' : selectedCategory == 1 ? 'Teacher' : 'Other'}",
                    style: const TextStyle(fontSize: 16, color: Colors.black54),
                  ),
                  const SizedBox(height: 24),

                  // Input Fields
                  buildInputFields(),

                  const SizedBox(height: 16),

                  // Category Selection
                  ToggleButtons(
                    borderRadius: BorderRadius.circular(20),
                    isSelected: [
                      selectedCategory == 0,
                      selectedCategory == 1,
                      selectedCategory == 2
                    ],
                    selectedColor: Colors.white,
                    fillColor: Color(0xFFFFA500), // Use the same orange color for the toggle button
                    onPressed: (index) {
                      setState(() {
                        selectedCategory = index;
                      });
                    },
                    children: const [
                      Padding(
                          padding: EdgeInsets.symmetric(horizontal: 20),
                          child: Text("Student")),
                      Padding(
                          padding: EdgeInsets.symmetric(horizontal: 20),
                          child: Text("Teacher")),
                      Padding(
                          padding: EdgeInsets.symmetric(horizontal: 20),
                          child: Text("Other")),
                    ],
                  ),

                  const SizedBox(height: 24),

                  // Sign Up Button
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Color(0xFFFFA500), // Use orange color for the button
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(25),
                        ),
                      ),
                      onPressed: () {
                        if (_formKey.currentState!.validate()) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('Signup Successful!'),
                            ),
                          );
                          // Navigate to HomeScreen
                          Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(
                                builder: (context) => HomeScreen()),
                          );
                        }
                      },
                      child: const Text(
                        "Sign Up",
                        style: TextStyle(fontSize: 18, color: Colors.white),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget buildInputFields() {
    switch (selectedCategory) {
      case 1: // Teacher
        return Column(
          children: [
            buildTextField("Full Name", Icons.person),
            const SizedBox(height: 10),
            buildTextField("Username", Icons.account_circle),
            const SizedBox(height: 10),
            buildTextField("Email Address", Icons.email, isEmail: true),
            const SizedBox(height: 10),
            buildTextField("Password", Icons.lock, isPassword: true),
          ],
        );
      case 2: // Other
        return Column(
          children: [
            buildTextField("Full Name", Icons.person),
            const SizedBox(height: 10),
            buildTextField("Email Address", Icons.email, isEmail: true),
            const SizedBox(height: 10),
            buildTextField("Password", Icons.lock, isPassword: true),
            const SizedBox(height: 10),
            buildTextField("Mobile Number", Icons.phone, isPhone: true),
          ],
        );
      default: // Student
        return Column(
          children: [
            buildTextField("Full Name", Icons.person),
            const SizedBox(height: 10),
            buildTextField("Registration No.", Icons.numbers),
            const SizedBox(height: 10),
            buildTextField("Email Address", Icons.email, isEmail: true),
            const SizedBox(height: 10),
            buildTextField("Password", Icons.lock, isPassword: true),
            const SizedBox(height: 10),
            buildTextField("Mobile Number", Icons.phone, isPhone: true),
          ],
        );
    }
  }

  Widget buildTextField(String label, IconData icon,
      {bool isPassword = false, bool isEmail = false, bool isPhone = false}) {
    return TextFormField(
      obscureText: isPassword ? _obscurePassword : false,
      keyboardType: isEmail
          ? TextInputType.emailAddress
          : isPhone
          ? TextInputType.phone
          : TextInputType.text,
      decoration: InputDecoration(
        labelText: label,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12.0),
        ),
        filled: true,
        fillColor: Colors.white,
        prefixIcon: Icon(icon),
        suffixIcon: isPassword
            ? IconButton(
          icon: Icon(_obscurePassword
              ? Icons.visibility_off
              : Icons.visibility),
          onPressed: () {
            setState(() {
              _obscurePassword = !_obscurePassword;
            });
          },
        )
            : null,
      ),
      validator: (value) {
        if (value == null || value.isEmpty) return 'This field is required';
        return null;
      },
    );
  }
}
