package com.example.item_radar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
